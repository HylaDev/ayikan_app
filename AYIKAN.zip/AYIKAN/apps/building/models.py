from django.db import models
from apps.catalogue.models import Color
from django.contrib.auth.models import User
from apps.catalogue.models import Product, Color, ProductImage

class Building(models.Model):
    user = models.ManyToManyField(
        User,
        verbose_name="User")
    cadran = models.ForeignKey(Product, related_name="Cadran", on_delete=models.CASCADE, verbose_name="Cadran", null=True, blank=True)
    bracelet  = models.ForeignKey(Product, related_name="Bracelet", on_delete=models.CASCADE, verbose_name="Bracelet", null=True, blank=True)
    couleur = models.ForeignKey(Color, on_delete=models.CASCADE, verbose_name="Couleur du bracelet", null=True, blank=True)
    image = models.ForeignKey(ProductImage, on_delete=models.CASCADE, verbose_name="Image du cadran", null=True, blank=True)
    enregistrement = models.IntegerField(null=True, blank=True, verbose_name="Nombre d'enregistrement")

