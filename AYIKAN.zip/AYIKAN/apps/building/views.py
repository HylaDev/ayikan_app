from django.shortcuts import render
from apps.catalogue.models import *





def index(request):
	produits=Product.objects.all()
	return render(request, 'oscar/building/index.html',{'produits':produits})


def about(request):
	return render(request, 'oscar/building/about.html')