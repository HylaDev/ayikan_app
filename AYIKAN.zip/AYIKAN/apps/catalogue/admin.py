from oscar.apps.catalogue.admin import *  # noqa
from django.contrib import admin
from .models import *

admin.site.register(Color)