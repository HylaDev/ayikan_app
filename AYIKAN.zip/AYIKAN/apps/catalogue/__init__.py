default_app_config = 'apps.catalogue.apps.CatalogueConfig'
