from django.db import models

from oscar.apps.catalogue.abstract_models import AbstractProduct, AbstractProductImage
from colorfield.fields import ColorField
from django.core.exceptions import ValidationError

from django.utils.translation import gettext_lazy as _


class Color(models.Model):
    color = ColorField(format='hexa', blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.color

class Product(AbstractProduct):
    millimetre = models.FloatField(verbose_name='Millimetre', blank=True, null=True)
    couleur  = models.ManyToManyField(Color, verbose_name='Couleur')

class ProductImage(AbstractProductImage):
    name = models.CharField(max_length=255, verbose_name='Product Image', null=True, blank=True)

from oscar.apps.catalogue.models import *
