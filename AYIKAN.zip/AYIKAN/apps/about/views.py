from django.shortcuts import render


def about_us(request):
    return render( request,'oscar/about/about.html' )
    
