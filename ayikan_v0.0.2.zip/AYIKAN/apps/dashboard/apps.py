import oscar.apps.dashboard.apps as apps


class DashboardConfig(apps.DashboardConfig):
    name = 'apps.dashboard'
