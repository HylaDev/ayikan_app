from oscar.apps.dashboard.models import *  # noqa isort:skip
