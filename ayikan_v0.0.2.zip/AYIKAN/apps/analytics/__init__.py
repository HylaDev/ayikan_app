default_app_config = 'apps.analytics.apps.AnalyticsConfig'
