from oscar.apps.analytics.models import *  # noqa isort:skip
