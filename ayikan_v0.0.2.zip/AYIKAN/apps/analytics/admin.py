from oscar.apps.analytics.admin import *  # noqa
