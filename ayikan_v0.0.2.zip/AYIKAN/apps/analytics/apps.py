import oscar.apps.analytics.apps as apps


class AnalyticsConfig(apps.AnalyticsConfig):
    name = 'apps.analytics'
