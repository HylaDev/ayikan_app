default_app_config = 'apps.partner.apps.PartnerConfig'
