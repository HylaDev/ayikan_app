from oscar.apps.partner.admin import *  # noqa
