from oscar.apps.voucher.admin import *  # noqa
