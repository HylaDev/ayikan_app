import oscar.apps.voucher.apps as apps


class VoucherConfig(apps.VoucherConfig):
    name = 'apps.voucher'
