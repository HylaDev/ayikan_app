from itertools import product
from multiprocessing import context
from django.shortcuts import render, redirect
from apps.catalogue.models import *
from oscar.core.loading import get_model
from django.db.models import Q
from .forms import *
from django.urls import reverse
Product = get_model('catalogue', 'Product')
ProductCategory = get_model('catalogue', 'ProductCategory')


def shop(request):
	products=Product.objects.all()
	context={'products':products}
	return render(request, 'oscar/catalogue/shop.html',context)

def cadran(request):
    cat = Category.objects.get(name__icontains='cadran')
    produits = cat.product_set.all()
    context={'produits':produits}
    return render(request, 'oscar/building/list.html', context)

def custom(request, upc):
    cadran = Product.objects.get(upc = upc)  
    cat = Category.objects.get(name__icontains='bracelet')
    cadran_millimetre = Millimetre.objects.filter(product = cadran)
    brac = cat.product_set.all()
    bracelet = brac.filter(millimetre__in = cadran_millimetre)

    context = {'cadran': cadran, 'bracelet':bracelet}
    return render(request, 'oscar/building/new.html', context)

def preview(request, cad, brac):
    user = request.user
    cadran = Product.objects.get(upc = cad)
    bracelet = ProductImage.objects.get(id = brac)
    
    buildings = Building.objects.all()
    if buildings:
        see = False
        for building in buildings:
            if building.cadran == cadran and building.image_bracelet == bracelet:
                see = True
                Customers.objects.create(
                    user = user, 
                    building = building
                )
        if see == False:
            building = Building.objects.create(
                cadran = cadran,
                image_bracelet = bracelet,
                bracelet = bracelet.product,
                #image_cadran = cadran.primary_image,
                #enregistrement = 1
            )
            Customers.objects.create(
                    user = user, 
                    building = building
                )
            print('Created')

    else:

        building = Building.objects.create(
                cadran = cadran,
                image_bracelet = bracelet,
                bracelet = bracelet.product,
                #image_cadran = cadran.primary_image,
            )
        Customers.objects.create(
                    user = user, 
                    building = building
                )
    
    context = {'cadran': cadran, 'bracelet': bracelet}
    return render(request, 'oscar/building/preview.html', context)

def my_custom(request):
    return render(request, 'oscar/building/my_custom.html')
