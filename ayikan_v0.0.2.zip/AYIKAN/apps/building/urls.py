from django.urls import path
from .views import * 

urlpatterns = [
    path('shop/', shop, name="shop"),
    path('list', cadran, name='customization'),
    path('custom/<str:upc>', custom, name='custom'),
    path('preview/<str:cad>/<int:brac>', preview, name='preview'),
    path('my_custom', my_custom, name='my_custom')
]