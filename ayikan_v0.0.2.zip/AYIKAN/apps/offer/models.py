from oscar.apps.offer.models import *  # noqa isort:skip
