from oscar.apps.offer.admin import *  # noqa
