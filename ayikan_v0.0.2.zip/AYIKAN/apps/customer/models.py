from oscar.apps.customer.models import *  # noqa isort:skip
