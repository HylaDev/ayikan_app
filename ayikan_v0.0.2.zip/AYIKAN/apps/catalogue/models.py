from django.db import models

from oscar.apps.catalogue.abstract_models import AbstractProduct, AbstractProductImage
from colorfield.fields import ColorField
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User
from oscar.core.compat import AUTH_USER_MODEL

class Millimetre(models.Model):
    taille = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.taille

class Product(AbstractProduct):
    building = models.ForeignKey('Building', on_delete=models.CASCADE, null=True, blank=True)
    millimetre = models.ManyToManyField('Millimetre', verbose_name = _("Millimetre"))

    
class Building(models.Model):
    cadran = models.ForeignKey('catalogue.Product', related_name='cadran',on_delete=models.CASCADE, verbose_name="Cadran", null=True, blank=True)
    bracelet  = models.ForeignKey('catalogue.Product', related_name='bracelet', on_delete=models.CASCADE, verbose_name="Bracelet", null=True, blank=True)
    image_bracelet = models.ForeignKey('catalogue.ProductImage',related_name="BraceletImage", on_delete=models.CASCADE, verbose_name="Image du bracelet", null=True, blank=True)
    image_cadran = models.ForeignKey('catalogue.ProductImage', related_name="CadranImage", on_delete=models.CASCADE, verbose_name="Image du cadran", null=True, blank=True)
    saved = models.IntegerField(null=True, blank=True, verbose_name="Nombre d'enregistrement")
    date_created = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return str( self.cadran.title + ' avec ' + self.bracelet.title)

class Customers(models.Model):
    user = models.ForeignKey(
        AUTH_USER_MODEL, related_name='customers', on_delete=models.CASCADE, null=True, blank=True,
        verbose_name=_("User"))
    building = models.ForeignKey(Building, on_delete=models.CASCADE, null=True, blank=True, verbose_name=_("Constitution") )
    date_created = models.DateTimeField(_("date created"),auto_now_add=True)
    date_saved = models.DateTimeField(_("date saved"),auto_now_add=True)
    saved = models.BooleanField(_("saved"),default=False)

from oscar.apps.catalogue.models import *
