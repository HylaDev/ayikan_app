from oscar.apps.address.models import *  # noqa isort:skip
