from oscar.apps.address.admin import *  # noqa
