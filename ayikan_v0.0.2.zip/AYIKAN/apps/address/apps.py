import oscar.apps.address.apps as apps


class AddressConfig(apps.AddressConfig):
    name = 'apps.address'
