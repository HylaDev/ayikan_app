default_app_config = 'apps.search.apps.SearchConfig'
