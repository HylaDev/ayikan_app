import oscar.apps.search.apps as apps


class SearchConfig(apps.SearchConfig):
    name = 'apps.search'
