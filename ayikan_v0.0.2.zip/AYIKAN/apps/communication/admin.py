from oscar.apps.communication.admin import *  # noqa
