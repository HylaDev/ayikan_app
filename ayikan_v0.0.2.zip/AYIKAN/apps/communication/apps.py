import oscar.apps.communication.apps as apps


class CommunicationConfig(apps.CommunicationConfig):
    name = 'apps.communication'
