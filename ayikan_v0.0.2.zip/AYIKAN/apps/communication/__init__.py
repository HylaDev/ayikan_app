default_app_config = 'apps.communication.apps.CommunicationConfig'
