from oscar.apps.communication.models import *  # noqa isort:skip
