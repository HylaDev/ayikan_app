import oscar.apps.shipping.apps as apps


class ShippingConfig(apps.ShippingConfig):
    name = 'apps.shipping'
