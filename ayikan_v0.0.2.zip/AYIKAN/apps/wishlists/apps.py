import oscar.apps.wishlists.apps as apps


class WishlistsConfig(apps.WishlistsConfig):
    name = 'apps.wishlists'
