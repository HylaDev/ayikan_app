default_app_config = 'apps.wishlists.apps.WishlistsConfig'
