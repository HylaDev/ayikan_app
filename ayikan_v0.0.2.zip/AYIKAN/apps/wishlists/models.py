from oscar.apps.wishlists.models import *  # noqa isort:skip
