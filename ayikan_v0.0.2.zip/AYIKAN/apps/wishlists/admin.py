from oscar.apps.wishlists.admin import *  # noqa
