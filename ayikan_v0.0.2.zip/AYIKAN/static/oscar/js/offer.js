

(function ($) {
    // USE STRICT
    "use strict";

        /*==================================================================
        [ slide1 ]*/
        $('.carousel-slide').each(function(){
            var carouselSlide = $(this);
            var slide1 = $(this).find('.slide1');


            var itemslide1 = $(slide1).find('.slide-item1');
            var layerslide1 = $(slide1).find('.layer-slide1');
            var actionslide1 = [];
            

            $(slide1).on('init', function(){
                var layerCurrentItem = $(itemslide1[0]).find('.layer-slide1');

                for(var i=0; i<actionslide1.length; i++) {
                    clearTimeout(actionslide1[i]);
                }

                $(layerslide1).each(function(){
                    $(this).removeClass($(this).data('appear') + ' visible-true');
                });

                for(var i=0; i<layerCurrentItem.length; i++) {
                    actionslide1[i] = setTimeout(function(index) {
                        $(layerCurrentItem[index]).addClass($(layerCurrentItem[index]).data('appear') + ' visible-true');
                    },$(layerCurrentItem[i]).data('delay'),i); 
                }        
            });


            var showDot = false;
            if($(carouselSlide).find('.wrap-slide1-dots').length > 0) {
                showDot = true;
            }

            $(slide1).slick({
                pauseOnFocus: false, 
                pauseOnHover: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                fade: true,
                speed: 1000,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 6000,
                arrows: true,
                appendArrows: $(carouselSlide),
                prevArrow:'<button class="arrow-slide1 prev-slide1"><i class="zmdi zmdi-caret-left"></i></button>',
                nextArrow:'<button class="arrow-slide1 next-slide1"><i class="zmdi zmdi-caret-right"></i></button>',
                dots: showDot,
                appendDots: $(carouselSlide).find('.wrap-slide1-dots'),
                dotsClass:'slide1-dots',
                customPaging: function(slick, index) {
                    var linkThumb = $(slick.$slides[index]).data('thumb');
                    var caption = $(slick.$slides[index]).data('caption');
                    return  '<img src="' + linkThumb + '">' +
                            '<span class="caption-dots-slide1">' + caption + '</span>';
                },
            });

            $(slide1).on('afterChange', function(event, slide, currentSlide){ 

                var layerCurrentItem = $(itemslide1[currentSlide]).find('.layer-slide1');

                for(var i=0; i<actionslide1.length; i++) {
                    clearTimeout(actionslide1[i]);
                }

                $(layerslide1).each(function(){
                    $(this).removeClass($(this).data('appear') + ' visible-true');
                });

                for(var i=0; i<layerCurrentItem.length; i++) {
                    actionslide1[i] = setTimeout(function(index) {
                        $(layerCurrentItem[index]).addClass($(layerCurrentItem[index]).data('appear') + ' visible-true');
                    },$(layerCurrentItem[i]).data('delay'),i); 
                }
                         
            });

        });

                

})(jQuery);